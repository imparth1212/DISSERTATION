document.addEventListener('DOMContentLoaded', () => {
    console.log('JavaScript Loaded');

    // Display a greeting message based on the time of day
    const greetingElement = document.createElement('p');
    const hours = new Date().getHours();
    let greetingMessage;

    if (hours < 12) {
        greetingMessage = 'Good morning!';
    } else if (hours < 18) {
        greetingMessage = 'Good afternoon!';
    } else {
        greetingMessage = 'Good evening!';
    }

    greetingElement.textContent = greetingMessage;
    document.body.prepend(greetingElement);

    // Add a button with a click event
    const button = document.createElement('button');
    button.textContent = 'Click me';
    document.body.appendChild(button);

    button.addEventListener('click', () => {
        alert('Button clicked!');
        console.log('Button was clicked at ' + new Date().toLocaleTimeString());
    });

    console.log('Greeting message and button added to the DOM.');
});
